/// @ref core
/// @file glm/geometric.hpp

#pragma once

#include "detail/func_geometric.hpp"
